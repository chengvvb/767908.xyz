﻿function fastSearch() {
	var x = document.getElementById("big-search");
	if (x.style.display == "none") {
		x.style.display = "block";
	} else {
		x.style.display = "none";
	}
}
function fastCloseSearch () {
	var close = document.getElementById("big-search"); 
	  if (close.style.display == "block") {
		close.style.display = "none";
	} 
}
function fastSearchMobile() {
	var x = document.getElementById("big-search-mobile");
	if (x.style.display == "none") {
		x.style.display = "block";
	} else {
		x.style.display = "none";
	}
}
function fastCloseSearchMobile () {
	var close = document.getElementById("big-search-mobile"); 
	  if (close.style.display == "block") {
		close.style.display = "none";
	} 
}